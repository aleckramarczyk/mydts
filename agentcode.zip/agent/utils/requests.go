package utils

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
)

func SendUpdateRequest(u *Unit) error {
	url := getEndpoint()
	body, err := json.Marshal(u)
	if err != nil {
		log.Printf("Error encoding u object: %s\n", err)
		return err
	}
	resp, err := http.Post(url, "application/json", bytes.NewBuffer(body))
	if err != nil {
		log.Printf("Error creating POST request: %s\n", err)
		return err
	}
	defer resp.Body.Close()
	return nil
}

func getEndpoint() string {
	return fmt.Sprintf("http://%s:%s", AgentConfig.ApiHost, AgentConfig.ApiEndpoint)
}
